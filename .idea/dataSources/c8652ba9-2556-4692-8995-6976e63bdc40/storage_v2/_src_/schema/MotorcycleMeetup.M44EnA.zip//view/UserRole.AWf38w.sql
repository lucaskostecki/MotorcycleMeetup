create view UserRole as
select `u`.`Username`                        AS `Username`,
       `MotorcycleMeetup`.`Roles`.`RoleID`   AS `RoleID`,
       `MotorcycleMeetup`.`Roles`.`RoleName` AS `RoleName`
from (`MotorcycleMeetup`.`Roles`
       left join `MotorcycleMeetup`.`Users` `u` on ((`u`.`UserID` = `MotorcycleMeetup`.`Roles`.`UserID`)));

